CKEDITOR.editorConfig = function (config) {
  config.height = 400;
  config.language = 'en';
  config.uiColor = '#ffffff';

  config.image_previewText = "Image Preview";

  config.allowedContent = true;
  config.extraPlugins = 'imgur';
  config.imgurClientId = 'e9ee945efd534ff';
  config.imgurClientSecret = '6ddccb11862335b608bb8fe15b15c25d1cfe5f2b';
  config.imgurRefreshToken = '6c78f8294c5fae650335f2cb7f7a6c72a10131bc';

  config.toolbar = [
  	{ name: 'document', items: [ 'Source', '-', 'Save', 'NewPage', 'Templates', 'Preview', '-' ] },
  	{ name: 'clipboard', items: [ 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo' ] },
    { name: 'paragraph', items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-' ] },
    { name: 'insert', items: [ 'Image', 'Imgur', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak' ] },
		'/',
    { name: 'styles', items: [ 'Styles', 'Format', 'Font', 'FontSize' ] },
		{ name: 'basicstyles', items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat' ] },
    { name: 'colors', items: [ 'TextColor', 'BGColor' ] },
    { name: 'editing', items: [ 'Find', 'Replace', '-', 'SelectAll', '-' ] },
    { name: 'links', items: [ 'Link', 'Unlink' ] },
    { name: 'tools', items: [ 'Maximize', 'ShowBlocks' ] },
  ];
};
